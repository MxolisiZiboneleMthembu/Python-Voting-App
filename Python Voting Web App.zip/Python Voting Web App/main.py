from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/')
def page_load():
    candidates = ['Lionel Messi', 'Christian Ronaldo','Erling Haaland','Kylian Mbappe',
                  'Sadio Mane', 'Virgil van Dijk']

    return render_template("homepage.html", candidates=candidates)


@app.route('/result', methods=['POST'])
def result_load():
    result = request.form
    voted_candidate = result['candidate']

    return render_template("results.html", voted_candidate=voted_candidate)


if __name__ == '__main__':
    app.run()
